import { test, expect } from '@playwright/test';
import { BasePage } from '../e2e/PageObjectModel/pages/BasePage';

test('Example test', async ({ page }) => {
  const basePage = new BasePage(page);
  await basePage.navigate('https://playwright.dev');
  await expect(page).toHaveTitle(/Playwright/);
});
