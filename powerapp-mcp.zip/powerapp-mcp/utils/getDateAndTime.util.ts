export const getDateAndTime = {
    getDate(): string {
      const currentDate = new Date();
      const month = `${currentDate.getMonth() + 1}`.toString().padStart(2, "0");
      const day = `${currentDate.getDate()}`.toString().padStart(2, "0");
      const year = `${currentDate.getFullYear()}`;
      const getDate = month + "/" + day + "/" + year;
      return getDate;   //return: mm/dd/yyyy
    },
    getSimpleDate(): string {
      const currentDate = new Date();
      const month = `${currentDate.getMonth() + 1}`;
      const day = `${currentDate.getDate()}`;
      const year = `${currentDate.getFullYear()}`;
      const getDate = month + "/" + day + "/" + year;
      return getDate;   // return: m/d/yyyy 1/9/2025
    },
    getTime(): string {
        const currentDate = new Date();
        const hours = currentDate.getHours().toString().padStart(2, "0");
        const minutes = currentDate.getMinutes().toString().padStart(2, "0");
        const timeIs = `${hours}:${minutes}`;
        return timeIs; //  hh:mm
    },
    getYearMonthDay(): string {
        const currentDate = new Date()
        const month = `${currentDate.getMonth() + 1}`.toString().padStart(2, "0")
        const day = `${currentDate.getDate()}`.toString().padStart(2, "0")
        const year = `${currentDate.getFullYear()}`
        const getDate = year + "-" + month + "-" + day
        return getDate;   //return: yyyy-mm-dd
    },

    getDateddmmyyyy(): string {
      const currentDate = new Date()
      const dd = `${currentDate.getDate()}`.toString().padStart(2, "0")
      const mm = `${currentDate.getMonth() + 1}`.toString().padStart(2, "0")
      const yyyy = `${currentDate.getFullYear()}`
      const getDate = dd + "/" + mm + "/" + yyyy
      return getDate;
    }
}