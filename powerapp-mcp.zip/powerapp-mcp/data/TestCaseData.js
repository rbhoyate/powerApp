export const testCaseData = {
  testStatusFinished: "FINISHED",
  testResultPass: "PASSED",
  commentAdded: "Comment has been added",
  commentDeleted: "Comment has been deleted",
  userComment: " Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.",
  projectName: "00000005 AUTOMATION 333 AH",
  testResultOverall: "TEST RESULTS OVERALL",
  testResultPerCategory: "TEST RESULTS PER  C ATE G ORY",
  yourComment: "C OMMENTS",
  oneTestCase: "1Test",
  twoTestCases: "2Test",
  projectNameTwo: "0000099999 AUTOMATION 234AH  C EBRA-3762",
  eRP_lAHComment: "ERP - LAH  C OMMENTS",
  testCaseID: "Test  C ase Id",
  testCase: "Test  C ase",
  requirementID: "Req ID",
  tM_Comment: "TM  C omment",
  bTV_Comment: "BTV  C omment",
  testCaseTitle: "00 Automation",
  versionOne: 0,
  C_Column: "Test Specification",
  L_Column: "Relevant For Level Release/BMG",
  temperatureColumnValue: "12; 12; 12",
  excelFilePath: '../../data/uploadFiles/TMP_Export_0000099999 Automation_212_P0 - Prototype_ 2025.xlsx'
}

export const tooltipDataForDut = {
  planned: "Planned : 5 Started or Assigned : 0 Approved, Canceled, In Review or Finished : 0",
  started: "Planned : 0 Started or Assigned : 5 Approved, Canceled, In Review or Finished : 0",
  approved: "Planned : 0 Started or Assigned : 4 Approved, Canceled, In Review or Finished : 1",
}

