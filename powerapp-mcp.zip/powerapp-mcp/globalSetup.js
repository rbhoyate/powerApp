module.exports = async () => {
  console.log('Global setup for PowerApp MCP tests');
};
